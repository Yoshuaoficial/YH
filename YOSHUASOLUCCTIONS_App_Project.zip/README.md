# YOSHUASOLUCCTIONS App
Proyecto React + Capacitor listo para compilar como APK.